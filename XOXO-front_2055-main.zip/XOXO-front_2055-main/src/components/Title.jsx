const Title = () => {
    return (
        <>
            <div className="w-100 fixed_size1 text-white text-center my-3">
                <h1 className="m-0">Tic-Tac-Toe</h1>
            </div>
        </>
    )
}

export default Title