
import './App.css'
import 'bootstrap/dist/css/bootstrap.min.css';
import Router from './components/Router';

function App() {
  return (
    <div className="header h-100">
      <Router/>
    </div>
  )
}

export default App